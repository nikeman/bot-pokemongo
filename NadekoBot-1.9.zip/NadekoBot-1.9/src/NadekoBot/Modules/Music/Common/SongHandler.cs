﻿using NLog;

namespace NadekoBot.Modules.Music.Common
{
    public static class SongHandler
    {
        private static readonly Logger _log = LogManager.GetCurrentClassLogger();
    }
}
