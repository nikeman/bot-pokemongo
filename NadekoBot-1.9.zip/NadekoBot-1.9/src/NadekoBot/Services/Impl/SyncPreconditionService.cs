﻿namespace NadekoBot.Services.Impl
{
    public class SyncPreconditionService
    {
        
    }
}
